//
//  Flight.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight{
    
    var flightID : String
    var flightFrom : String?
    var flightTo : String?
    var flightDate : Date?
    var airlineID : Int?
    var airplaneID  : Int?
    var pilotID : Int?
}




