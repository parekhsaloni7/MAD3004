//
//  Reservation.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation : Passenger{
    
    var reservationID: Int = 0
    private var reservationDesc : String = ""
    private var resPassengerID : String = ""
    private var resFlightID : String = ""
    private var resDate : Date
    private var resSeatNumber : String = ""
    private var resStatus : String = ""
    private var resMealtype: String = ""
    
    
}
