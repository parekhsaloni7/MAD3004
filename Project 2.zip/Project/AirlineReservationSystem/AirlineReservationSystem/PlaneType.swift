//
//  PlaneType.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PlaneType{
    
    var planeTypeID: String
    var planeTotalSeats : Int
    var planeTypeSeatMap : CGVector
    
    
    init(planeTypeID : String, planeTotalSeats : Int, planetypeSeat: CGVector) {
        self.planeTypeID=planeTypeID
        self.planeTotalSeats=planeTotalSeats
        self.planeTypeSeatMap = planeTypeSeatMap
    }
}
