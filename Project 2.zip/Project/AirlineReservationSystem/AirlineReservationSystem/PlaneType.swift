//
//  PlaneType.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PlaneType : Airlines{
   
    
    
    var planeTypeID: Int = 0
    var planeTotalSeats : Int
    var planeTypeSeatMap : [String:Int]
    
    
    
    
    init(planeTypeID : Int, planeTotalSeats : Int, planetypeSeat: [String:Int]) {
        self.planeTypeID = planeTypeID
        self.planeTotalSeats=planeTotalSeats
        self.planeTypeSeatMap = ["A1":1,"":2,"":3,"":4]
    }
}
