//
//  Passenger.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Passenger{
    var passengerID : Int?
    private var passengerName: String?
    private var passportNumber: String?
    private var passengerMobile: String?
    private var passengerEmail : String?
    private var passengerAddress : String?
    private var passengerBirthDate : Date?
}
