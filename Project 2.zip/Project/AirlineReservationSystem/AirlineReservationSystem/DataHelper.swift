//
//  DataHelper.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class EmployeeList {
    var EmployeeList = [Int : Employee]()
    
    init(){
        self.loadEmployeeData()
    }
    
    func loadEmployeeData(){
        EmployeeList = [:]
        
        let employee1 = Employee(employeeID: 1,employeeName: "Saloni",employeeEmail:"s@g.com",employeeMobile:"45678945787",employeeAddress:"Scarborough",employeeDesignation:"Pilot",employeeSinNumber:"4578787454547")
        EmployeeList[employee1.EmployeeID!]=employee1
        
        let employee2 = Employee(employeeID: 2,employeeName: "Shivam",employeeEmail:"shivam@g.com",employeeMobile:"457895558885",employeeAddress:"Scarborough",employeeDesignation:"Pilot",employeeSinNumber:"787874548778")
        EmployeeList[employee1.EmployeeID!]=employee1
    }
}
