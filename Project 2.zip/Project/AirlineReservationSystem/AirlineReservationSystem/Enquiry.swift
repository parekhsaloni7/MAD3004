//
//  Enquiry.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Enquiry : Airlines{
    
    var enquiryID: Int = 0
    var enquiryType: String?
    var enquiryTitle : String?
    var enquiryDesc : String?
    var enquiryDate : Date?
    
    
}
