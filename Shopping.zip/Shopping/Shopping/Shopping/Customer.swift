//
//  Customer.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Customer{
    var customerID : String?
    private var customerName: String?
    private var address: String?
    private var email: String?
    private var creditCardInfo: String?
    private var shoppingInfo: String?
    
    var CustomerName : String?{
        get{
            return self.customerName
        }
        
        set{
            self.customerName = newValue
            //newvalue variable is by default available in set method
        }
    }
    var Email : String?{
        get{
            return self.email
        }
        
        set{
            self.email = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var Address : String?{
        get{
            return self.address
        }
        
        set{
            self.address = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var CreditCardInfo : String?{
        get{
            return self.creditCardInfo
        }
        
        set{
            self.creditCardInfo = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var ShoppingInfo : String?{
        get{
            return self.shoppingInfo
        }
        
        set{
            self.shoppingInfo = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    
    //default initializer / constructor
    init() {
        self.customerID=""
        self.customerName=""
        self.email=""
        self.address=""
        self.creditCardInfo=""
        self.shoppingInfo=""
    }
    
    //parametrized initializer
    init(customerID: String, customerName: String,email: String,address: String,creditCardInfo: String,shippingInfo:String) {
        
        self.customerID=customerID
        self.customerName=customerName
        self.email=email
        self.address=address
        self.creditCardInfo=creditCardInfo
        self.shoppingInfo=shippingInfo
    }
    
    func displayData() -> String {
        var returnData = ""
        
        if self.customerID != nil{
            returnData += "\n Customer ID : " + self.customerID!
        }
     
        
        if self.customerName != nil{
            returnData += "\n Customer name : " + self.customerName!
        }
       
        
        if self.email != nil{
            returnData += "\n Customer Email : " + self.email!
        }
       
        
        if self.address != nil{
            returnData += "\n Customer Address : " + self.address!
        }
       
        
        if self.creditCardInfo != nil{
            returnData += "\n Credit Card info : " + self.creditCardInfo!
        }
       
        
        if self.shoppingInfo != nil{
            returnData += "\n Shipping Information : " + self.shoppingInfo!
        }
        return returnData
        
    }
    
    func registerUser(){
        print("Enter Customer ID: ")
        self.customerID=readLine()
        
        print("Enter Customer Name: ")
        self.customerName=readLine()
        
        print("Enter Customer Email: ")
        self.email=readLine()
        
        print("Enter Customer Address: ")
        self.address=readLine()
        
        print("Enter credit card number: ")
        self.creditCardInfo=readLine()
        
        print("Enter Shipping Info ")
        self.shoppingInfo=readLine()
        
   
    }
}
