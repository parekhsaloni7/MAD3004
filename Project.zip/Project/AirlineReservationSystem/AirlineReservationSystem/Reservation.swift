//
//  Reservation.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation {
    
    var reservationID: Int = 0
    private var reservationDesc : String
    private var resPassengerID : String
    private var resFlightID : String
    private var resDate : String
    private var resSeatNumber : String
    private var resStatus : String
    private var resMealtype: String
    
    init() {
        self.reservationID = 0
        self.reservationDesc = ""
        self.resPassengerID = ""
        self.resFlightID = ""
        self.resDate = ""
        self.resSeatNumber = ""
        self.resStatus = ""
        self.resMealtype = ""
    }
}
