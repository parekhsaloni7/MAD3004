//
//  Passenger.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Passenger{
    var passengerID : Int?
    private var passengerName: String?
    private var passportNumber: String?
    private var passengerMobile: String?
    private var passengerEmail : String?
    private var passengerAddress : String?
    private var passengerBirthDate : String?
    
    var PassengerName : String?{
        get{return self.passengerName}
        set{self.passengerName = newValue}
}
    var PassportNumber : String?{
        get{return self.passportNumber}
        set{self.passportNumber = newValue}
}
    var PassengerMobile : String?{
        get{return self.passengerMobile}
        set{self.passengerMobile = newValue}
}
    var PassengerEmail : String?{
        get{return self.passengerEmail}
        set{self.passengerEmail = newValue}
}
    var PassengerAddress : String?{
        get{return self.passengerAddress}
        set{self.passengerAddress = newValue}
}
    var PassengerBirthDate : String?{
        get{return self.passengerBirthDate}
        set{self.passengerBirthDate = newValue}
}
    
    init(){
        self.passengerID = 0
        self.passengerName = ""
        self.passportNumber = ""
        self.passengerMobile = ""
        self.passengerEmail = ""
        self.passengerAddress = ""
        self.passengerBirthDate = ""
    }
    
    init(passengerID: Int, passengerName : String, passportNumber : String,passengerMobile : String, passengerEmail : String, passengerAddress : String, passengerBirthDate : String){
        
        self.passengerID = passengerID
        self.passengerName = passengerName
        self.passportNumber = passportNumber
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        self.passengerBirthDate=passengerBirthDate
    }
    
    func registerUser(){
       /* print("Enter Passenger ID : ")
        self.passengerID = readLine()!*/
        print("Enter Passenger Name : ")
        self.passengerName = readLine()!
        print("Enter Passenger Passport Number : ")
        self.passportNumber = readLine()!
        print("Enter Passenger Email : ")
        self.passengerEmail = readLine()!
        print("Enter Passenger Address : ")
        self.passengerAddress = readLine()!
        print("Enter Passenger Birth Date : ")
        self.passengerBirthDate = readLine()!
        
    }
}
