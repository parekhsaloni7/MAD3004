//
//  main.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Welcome to Airline Reservation System!")

/*var Saloni = Employee()
Saloni.employeeID = 1
Saloni.EmployeeName="Saloni"
Saloni.Email="s@g.com"
Saloni.Mobile="123456789"
Saloni.Address="Scarborough"
Saloni.Designation="Pilot"
Saloni.SIN="456-456-4578"
print(Saloni.displayData())*/







