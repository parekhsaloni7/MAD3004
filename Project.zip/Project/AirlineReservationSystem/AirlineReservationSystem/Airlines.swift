//
//  Airlines.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Airlines{
    
    var airlineID : String
    var airlineDesc : String?
    var airline_type : String?
    
}





