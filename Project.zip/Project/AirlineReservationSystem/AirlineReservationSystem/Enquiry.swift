//
//  Enquiry.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Enquiry:Airlines,IDisplay {
    
    var enquiryID: Int?
    var enquiryType: String?
    var enquiryTitle : String?
    var enquiryDesc : String?
    var enquiryDate : String?
    
    var EnquiryID : Int?{
        get{return self.enquiryID}
        set{self.enquiryID=newValue}
    }
    
    var EnquiryType : String?{
        get{return self.enquiryType}
        set{self.enquiryType=newValue}
    }
    
    var EnquiryTitle : String?{
        get{return self.enquiryTitle}
        set{self.enquiryTitle=newValue}
    }
    
    var EnquiryDesc : String?{
        get{return self.enquiryDesc}
        set{self.enquiryDesc=newValue}
    }
    
    var EnquiryDate : String?{
        get{return self.enquiryDate}
        set{self.enquiryDate=newValue}
    }
    
    override init(){
        self.enquiryID = 0
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDesc = ""
        self.enquiryDate = ""
  }
    init(enquiryID:Int,enquiryType:String,enquiryTitle:String,enquiryDesc:String,enquiryDate:String){
        self.enquiryID=enquiryID
        self.enquiryType=enquiryType
        self.enquiryTitle=enquiryTitle
        self.enquiryDesc=enquiryDesc
        self.enquiryDate=enquiryDate
    }
    
    func displayData() -> String{
        var returnData = ""
        
        returnData += "\n Enquiry ID : \(self.enquiryID ?? 0)"
        returnData += "\n Enquiry Type : \(self.enquiryType ?? "")"
        returnData += "\n Enquiry Title : \(self.enquiryTitle ?? "")"
        returnData += "\n Enquiry Description : \(self.enquiryDesc ?? "")"
        returnData += "\n Enquiry Date : \(self.enquiryDate ?? "")"
        
        return returnData
    }
}
