//
//  Flight.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight {
    
    var flightID : String?
    var flightFrom : String?
    var flightTo : String?
    var flightDate : Date?
   
    
    var FlightID : String?{
        get{return self.flightID}
        set{self.flightID = newValue}
    }
    var FlightFrom : String?{
        get{return self.flightFrom}
        set{self.flightFrom = newValue}
    }
    var FlightTo : String?{
        get{return self.flightTo}
        set{self.flightTo = newValue}
    }
    var FlightDate : Date?{
        get{return self.flightDate}
        set{self.flightDate = newValue}
    }
 /*   var AirlineID : Int?{
        get{return self.airlineID}
        set{self.airlineID = newValue}
    }
    var AirplaneID : Int?{
        get{return self.planeTypeID}
        set{self.planeTypeID = newValue as! Int}
    }
    var EmployeeID : Int?{
        get{return self.employeeID}
        set{self.employeeID = newValue}
    }*/
    
     init() {
        self.flightID=""
        self.flightFrom=""
        self.flightTo=""
        self.flightDate=Date()
        //   self.AirlineID = 0
     //   self.planeTypeID = 0
        
    }
    
    //DICTIONARY
    var Airlines = [
        "airlineID":[01,02,03,04,05],
        "airlineName":["AirCanada","JetAirways","AirIndia","Indigo","SpiceJet"],
        "airlineType":["Domestic","International","Domestic","International","International"]
    ]
    
    var AirPlaneType=[
   // "airlinePlaneID":[01,02,03,04,05],
    "airplaneType": ["Boeing","Airbus","Jet"]
    
    ]
}




