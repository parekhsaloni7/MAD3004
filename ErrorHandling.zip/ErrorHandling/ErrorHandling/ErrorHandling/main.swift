//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()

/*do{
try request1.increaseLimit(accountNo: "S1300")
}
catch limitIncreaseError.ineligible{
    print("You must have an account with our bank...")
}
catch limitIncreaseError.noSavingAccount{
    print("Sorry.. Limit increase is provided only to the Saving account holders.")
}
catch limitIncreaseError.inSufficientBalance{
    print("Minimum $5000 balance is required for credit limit increase")
}
catch{
    print("Something unexpected happened.. Sorry for the service disruption")
}
 //do
 try catch throws do
 
 function should include catch
*/

do{
    try request1.increaseLimit(accountNo: "S1300")
}
catch is limitIncreaseError{
    print("You do not match any of the following criteria for the credit limit increase")
    print("""
1.No account with our bank
2.No Saving account
3.Insufficient balance in Savings account (minimum $5000)

""")
}

var s1 = Student()
s1.name = "JK"
Student.accNo = 123456
s1.display()

print("account no : \(Student.accNo!) ")

var s2 = Student()

print("Student count : \(Student.getStudentCount())")

var s3 = Parttime()
s3.display()
print(Parttime.getStudentCount())

var s4 = Student()
s4.name = "Gurjot"
s4.display()

//reference (casting)
//s4=Parttime()
//s4.display()


