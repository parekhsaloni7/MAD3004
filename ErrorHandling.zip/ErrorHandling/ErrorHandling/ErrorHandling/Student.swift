//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Student{
    var name: String?
    static var accNo: Int?
    static var countSt = 0
    init(){
        self.name = "Unknown"
        Student.accNo = 000
        Student.countSt += 1
        //static cannot be used with the instance
        //refer using class name for static variable
    }
    func display(){
        print("Student Name \(self.name ?? "Unknown")")
        print("Student Fees \(Student.accNo ?? 000)")
       
    }
    
    static func getStudentCount() -> Int{
        return countSt
    }
    //static fuction only uses static members
}

class Parttime: Student {
    var hours: Int?
    
    override init(){
        super.init()
        self.hours = 10
    }
    
    override func display() {
        print("hours : \(self.hours ?? 40)")
    }
}
