//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

/*var Santosh = Customer()
Santosh.customerID="C101"
//Santosh.customerName= "Santosh"
print(Santosh.displayData())

var Param = Customer(customerID: "C102", customerName: "Paramjeet", email: "param@mad.com", address: "Brampton", creditCardInfo: "454545445", shippingInfo: "Ship between 8 to 12")

print(Param.displayData())

var Saloni = Customer()
Saloni.registerUser()
print(Saloni.displayData())

Saloni.CustomerName="Sallu"
Saloni.ShoppingInfo="Deliver between 10 to 2"
print(Saloni.displayData())

Santosh.CustomerName = "Santosh"
Santosh.Email = "Santosh@mad.com"
Santosh.Address = "54 Marjary Ave. Downtown. Toronto"
Santosh.CreditCardInfo = "4545-4787-9686-7845"
Santosh.ShoppingInfo = "Deliver at Papa John's at 3PM "

print(Santosh.displayData())*/

//var epson=product(productID: 101, productName: "Projector", manufacturer: "Epson", unitPrice: 1000.1,category: ProductCategory.Appliances)
//ProductList[epson.ProductID!]=epson
//print(epson.displayData())

/*var handcream = product()
handcream.newProduct()
print(handcream.displayData())*/

var dataHelper = DataHelper()
dataHelper.displayProducts()
